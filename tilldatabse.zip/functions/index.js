const functions = require("firebase-functions");
const express=require('express');
const cors=require('cors');
const { StreetviewSharp } = require("@material-ui/icons");
const  stripe=require("stripe")('sk_test_51Ko8zKSJtLhMYkyUDKWhm8evqVqjIQOVQUQubI1i77lCRwKqPgPOkqNl0MpaEXyaHajy1CKdnZtrr6w3njezpPUQ00CnRcA8Dr')
//App


//App config
const app=express();

//Middleware
app.use(cors({origin: true}));
app.use(express.json());

//API routes
app.get("/",(request,response)=> response.status(200).send('hello world'))
app.post('/payments/create',async(request,response)=>{
    const total= request.query.total;
    console.log("Payment request recieved",total);
    const paymentIntent=await stripe.paymentIntents.create({
        amount:total,
        currency:"INR",

    });
    response.status(201).send({
        clientSecret:paymentIntent.client_secret,
    })
});
//Listen command
exports.api=functions.https.onRequest(app)