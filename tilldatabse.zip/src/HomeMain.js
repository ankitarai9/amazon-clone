import React from 'react'
import Header from'./Header';
import Home from "./HomeMain";
function HomeMain() {
  return (
    <div>
        <Header />
        <Home />
    </div>
  )
}

export default HomeMain