
import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs } from 'firebase/firestore';

import { getAuth,createUserWithEmailAndPassword} from "firebase/auth";

// import firebase from "firebase";
// // // Required for side-effects
// // require("firebase/firestore");

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyDZEJZpoi0RpK2Q241D3PAz9oRfobFCyag",
    authDomain: "clone-342fc.firebaseapp.com",
    projectId: "clone-342fc",
    storageBucket: "clone-342fc.appspot.com",
    messagingSenderId: "50484155166",
    appId: "1:50484155166:web:60c890d0468c20de52ef0f",
    measurementId: "G-0H2KCXPL7R"
  };

//   const firebaseApp = firebase.initializeApp(firebaseConfig);

// const db = firebaseApp.firestore();
// const auth = firebase.auth();
const app=initializeApp(firebaseConfig);
const db=getFirestore(app);
const auth= getAuth(app);
export {db,auth};

  
