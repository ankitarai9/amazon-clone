import { doc } from 'firebase/firestore';
import React,{useState,useEffect} from 'react';
import './Orders.css';
import { orderBy } from 'firebase/firestore';
import {useStateValue} from "./StateProvider";
import { onSnapshot,query } from "firebase/firestore";
import{db} from './firebase';

function Orders() {
  

  return (
    <div className='orders'>

        <h1>your order(s)</h1>
        

    </div>
  )
}

export default Orders